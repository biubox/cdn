#!/bin/sh
# ******************************************************
# Copyright ©2020 All rights reserved.
# Author       : FiixOne
# Last modified: 2020-05-05 14:54
# Email        : fiixone@163.com
# Filename     : sb.sh
# Description  : 
# ******************************************************
echo "##########################################################"
echo ' _____ _ _       ___               _____           _     '
echo '|  ___(_|_)_  __/ _ \ _ __   ___  |_   _|__   ___ | |___ '
echo '| |_  | | \ \/ / | | | `_ \ / _ \   | |/ _ \ / _ \| / __|'
echo '|  _| | | |>  <| |_| | | | |  __/   | | (_) | (_) | \__ \'
echo '|_|   |_|_/_/\_\\____/|_| |_|\___|   |_|\___/ \___/|_|___/'
echo '                                      bilibili   @FiixOne '
echo "##########################################################"
Line="##########################################################"

######个人配置信息
filename=""                     #文件名
filetype="*.wav"                #文件格式 ("默认.wav")
filepath="/home/su/Box/sb/"     #工程目录 (win10可修改至D盘 '/mnt/d/' 注意路径后斜杠不能少)
human="sleep 1"                 #无聊模式
cut_time="59"                   #切片时间,建议不要60s.
APPKEY="kVcnfD9iW2XVZSMaLMrtLYIz"               #百度appkey
APPSECRET="O9o1O213UgG5LFn0bDGNtoRN3VWl2du6"    #百度appsecret


######文件列表展示
list=`ls $filepath$filetype`
nu=0
for i in $list
    do
    nu=$(($nu+1))
    echo "$nu)-$i"
done

echo "请输入文件序号:"
read num
if [ "$num" -le "$nu" ];then
    echo $Line
    cd $filepath
    filename="`ls $filetype | head -$num | tail -1`"
    echo "\n注意!请确认本次处理文件:$num)-[$filename]\n"
else
    echo "选择错误,程序退出..."
    echo $Line
    exit
fi

######检测目录环境
if [ ! -d $filepath/tmp ] ;then
    echo "创建tmp目录..."
    mkdir -p $filepath/tmp 
fi
if [ -f $filepath/$filename.txt ] ;then
    echo "\n已经识别文件[$filename.txt]已存在,删除或移动后重新操作！\n"
    echo $Line
    exit    
fi

#echo "\n注意！本次识别的文件名为:[$filename]\n"
echo "继续运行将会清除上次识别的tmp文件..\n"
read -p "输入y继续运行，回车键退出：" res
echo $Line

if [ -z $res ];then
    exit -1
fi
if [ ${res} != "y" ];then
    exit -0
fi 

echo "验证成功"
echo "清除上次识别tmp文件.."
cd $filepath 
rm ./tmp/*   2>/dev/null
echo $Line


######切片源文件
echo "准备切片文件至tmp文件夹..."
$human
ffmpeg -i $filename -f segment -segment_time $cut_time -c copy ./tmp/%02d$filename 2>/dev/null 
echo "共计生成切片文件个数:  `ls -l ./tmp |grep "^-"|wc -l`"
echo $Line
$human


######转码采样16000 16位
cd ./tmp/
echo "转码开始..."
$human
listtmp=`ls  $filetype`
for itmp in  $listtmp
    do
    info=`ffprobe -show_streams  $itmp `  2>/dev/null
    bits_per_sample=`echo "$info" | grep  "bits_per_sample" | sed s/bits_per_sample=//g`
    codec_name=`echo "$info" | grep  "codec_name" | sed s/codec_name=//g`
    sample_rate=`echo "$info" | grep  "sample_rate" | sed s/sample_rate=//g`
    channels=`echo "$info" | grep  "channels" | sed s/channels=//g`
    #echo $Line
    echo "------转码[$itmp]中------"
    echo "编码名:$codec_name"
    echo "位:$bits_per_sample"
    echo "采样率:$sample_rate"
    echo "声道数:$channels"
    #echo $Line
    ffmpeg -y  -acodec $codec_name -ac $channels  -i $itmp  -acodec pcm_s16le -f s16le -ac 1  -ar 16000 $itmp.pcm 2>/dev/null
    #  -ar $sample_rate
done
echo "所有切片文件已经转码完成..."


#######百度语音识别
echo $Line
echo "\n开始在线识别语音？\n"
read -p "输入y开始识别，回车键退出：" res
if [ -z $res ];then
    exit -0
fi
if [ ${res} != "y" ];then
    exit -0
fi 
echo "验证成功"
echo $Line

# 根据文档填写PID，1537 表示识别普通话，使用输入法模型。
API_URL="http://vop.baidu.com/server_api"
DEV_PID="1537"
token_url="https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id=$APPKEY&client_secret=$APPSECRET"
# echo "Request token $token_url\n"
token_resp=$(curl -s "$token_url")
# echo "Response: $token_resp\n"
token=$(echo "${token_resp}" | grep -oP '"access_token"\s*:\s*"\K.+?(?=")')  # this works for Linux with GUN grep
# MacOS grep not support Perl(-P) syntax, so we use perl instead ;)
# token=$(echo "${token_resp}" | perl -nle 'print $& if m{"access_token"\s*:\s*"\K.+?(?=")}' )
echo "Got token: $token\n"
$human
ASR_URL="${API_URL}?dev_pid=${DEV_PID}&token=$token&cuid=123456"

# 需要识别的文件
FORMAT="pcm"  # support pcm/wav/amr 格式，极速版额外支持m4a 格式
RATE="16000"
# 极速版需要打开下面注释
# ASR_URL="${API_URL}?dev_pid=${DEV_PID}&lm_id={LM_ID}$&token=$token&cuid=123456"
headers="Content-Type: audio/$FORMAT;rate=$RATE"

listpcm=`ls *.pcm`
echo $Line
echo "准备识别文件如下:\n"  
echo "$listpcm\n"
echo $Line

for ipcm in  $listpcm
do
    echo "Request ASR...写入缓存txt中..."
    curl -X POST -s --data-binary "@$ipcm" -H "$headers" "$ASR_URL"   > ./$ipcm.txt
    echo "$ipcm写入$filename.txt中..."
    sed -n 's/\[\"/\n/p' ./$ipcm.txt | sed -n 's/\"\]/\n/p' | sed -n '1p'  >> $filepath/$filename.txt
    $human
done

echo "音频识别完成..."
echo $Line


#######识别文本转换行
echo "\n识别文本转换行"
echo "(本操作适合做字幕使用)\n"
read -p "输入y开始修改格式，回车键退出：" res
if [ -z $res ];then
    exit -0
fi
if [ ${res} != "y" ];then
    exit -0
fi 

echo "验证成功"
echo $Line

cd  $filepath
cp $filename.txt  换行版.$filename.txt

sed -i ':label;N;s/\n//;b label' 换行版.$filename.txt
sed -i 'y/。，？；：‘“、（）｀～！＠＃％＊/.,?;:\"\",()`~!@#%*/' 换行版.$filename.txt
sed -i 's/,\|\./\n/g' 换行版.$filename.txt

echo "输出文件为: 换行版.$filename.txt"
echo "完成..."
exit
